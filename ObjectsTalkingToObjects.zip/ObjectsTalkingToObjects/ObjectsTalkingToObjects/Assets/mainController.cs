﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mainController : MonoBehaviour
{
    
    public Spawner spawnerscript;
    public Rotate rotatescript;
    // Use this for initialization
    public SimpleMove movescript;
    void Start()
    {
        
        // rotatescript.rotateSpeed = 180f; 
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed == 0f) {
            rotatescript.rotateSpeed = 180f;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed >= 1){
            rotatescript.rotateSpeed = 0f;
        }
        if(Input.GetKeyDown(KeyCode.Alpha2)){
            spawnerscript.SpawnObject();
        }
        //if (Input.GetKeyUp(KeyCode.Alpha3))
        if (Input.GetKeyDown(KeyCode.Alpha3) && movescript.moveSpeed == 0f)
        {
            movescript.moveSpeed = 4f;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3) && movescript.moveSpeed >= 1)
        {
            movescript.moveSpeed = 0f;
        }
    }
}