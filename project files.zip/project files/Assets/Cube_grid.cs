﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube_grid : MonoBehaviour
{
    public GameObject spawn;
    // Use this for initialization
    void Start()
    {
        for (int x = 0; x <= 30; x++)
        {
            for (int y = 0; y <= 30; y++)
            {
                SpawnObject(new Vector3(x, y, 0));
            }
        }
    }
    public void SpawnObject(Vector3 loc)
    {
        GameObject child = Instantiate(spawn, loc, Quaternion.identity);
    }
    // Update is called once per frame
    ///void Update () {

    //}
}