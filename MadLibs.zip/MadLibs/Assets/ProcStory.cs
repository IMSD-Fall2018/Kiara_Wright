﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProcStory : MonoBehaviour
{

    public string[] beginnings;
    public string[] protagonists;
    public string[] places;

    void Start()
    {
        string finalstory = "";
        finalstory += beginnings[Random.Range(0, beginnings.Length)];
        finalstory += " ago there was a boy named ";
        //finalstory += "there was a ";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " who lived in ";
        finalstory += places[Random.Range(0, places.Length)];
        finalstory += ".";
        finalstory += " One day ";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " decieded to walk around and caught a glimps of All Might and Sitama fighting. ";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " saw how strong they were and got inspired.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " than began training for years hoping he can get as strong as they did.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " came acrossed a poster that said that there was a fighting tournoment comming up.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " got pumped.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " was hoping to get an opertunity to see what he was made of.";
        finalstory += " The tournoment was here before he knew it.";
        finalstory += " When.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " got there he noticed that All Might and Sitama was there and got realy excited.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " was getting ready for the first round. Though he was nervous ";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " made it through.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " was going through each match like it was a breeze, though it was tough.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " finally making it to the final round.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " then sees that his apponent was All Might.";
        finalstory += " The fight was a long one.";
        finalstory += " But in the end All Might won the fight.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " and All Might shook hands.";
        finalstory += protagonists[Random.Range(0, protagonists.Length)];
        finalstory += " and All Might goes off to train after words.";
        finalstory += " And Thats The End.";

        Debug.Log(finalstory);
    }

    // Update is called once per frame
    void Update()
    {

    }
}
