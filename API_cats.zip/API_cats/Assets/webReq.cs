﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class webReq : MonoBehaviour {
    public string url2 = "https://api.thecatapi.com/v1/breed/search";
    public string url = "https://api.thecatapi.com/v1/images/search";
    public string Api_key = "c507050b-a58a-4743-bc89-8c64c95d913b";
    public Text responseText;
    public RawImage img;

public void Request()
    {
        Renderer renderer = GetComponent<Renderer>();
        WWWForm form = new WWWForm();

        Dictionary<string, string> header = form.headers;
        header["x-api-key"] = Api_key;

        WWW request = new WWW(url,null,header);
        StartCoroutine(OnResponse(request));


    }

   private IEnumerator OnResponse(WWW req)
    {
        yield return req;

        Debug.Log(req);
      //  renderer.material.mainTexture = url.texture;
    }

    public class RootObject
    {
        public string Alt_names { get; set; }
        public int Experimental { get; set; }
        public int Hairless { get; set; }
        public int Hypoallergenic { get; set; }
        public string Id { get; set; }
        public string Life_span { get; set; }
        public string Name { get; set; }
        public int Natural { get; set; }
        public string Origin { get; set; }
        public int Rare { get; set; }
        public object Reference_image_id { get; set; }
        public int Rex { get; set; }
        public int Short_legs { get; set; }
        public int Suppressed_tail { get; set; }
        public string Temperament { get; set; }
        public string Weight_imperial { get; set; }
        public string Wikipedia_url { get; set; }
    }
}
