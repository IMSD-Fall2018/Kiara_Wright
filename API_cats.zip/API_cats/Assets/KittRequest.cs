﻿using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine;
using UnityEngine.Networking;

public class KittRequest : MonoBehaviour {

    public string Api_key = "c507050b-a58a-4743-bc89-8c64c95d913b";
    public string url = "https://api.thecatapi.com/v1/images/search?api_key=c507050b-a58a-4743-bc89-8c64c95d913b";
    public string url2 ="https://api.thecatapi.com/v1/breeds/search?api_key=c507050b-a58a-4743-bc89-8c64c95d913b";
    public string catUrl;


    IEnumerator Start()
    {

        // fetch the actual info, like you would from a browser
        WWW www = new WWW(url);
        WWW ww2 = new WWW(url2);

        // yield return waits for the download to complete before proceeding
        // but since this is in IEnumerator it wont stall the program outright
        yield return www;
        yield return ww2;
        // use a JSON Object to store the info temporarily
        // this makes it easy to access the data struture

        //Can get parameters

        JSONObject tempData = new JSONObject(www.text);
        Debug.Log(tempData);
  

        // this particular API stores all the data under the header
        // "consolidated_weather" so first get in there
        string catDetails = tempData[0]["url"].str;
        string catBreed = tempData[0]["breeds"].str;


        Debug.Log(catBreed);
        Debug.Log(tempData[0]["breeds"].ToString());
       // Debug.Log(catDetails.ToString());

      

        using (UnityWebRequest uwr = UnityWebRequestTexture.GetTexture(catDetails))
        {
            yield return uwr.SendWebRequest();

            if (uwr.isNetworkError || uwr.isHttpError)
            {
                Debug.Log(uwr.error);
            }
            else
            {
                // Get downloaded asset bundle
                var texture = DownloadHandlerTexture.GetContent(uwr);

                Renderer renderer = GetComponent<Renderer>();
                renderer.material.mainTexture = texture;

            }
        }


        // log it just to see whats up
        //	Debug.Log (weatherDetails.ToString());

        // now we can do cool stuff like...
        //	string WeatherType = weatherDetails[0]["weather_state_name"].str;
        //	Debug.Log (WeatherType);



    }

}
